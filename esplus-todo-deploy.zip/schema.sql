-- Cloudflare D1 SQLite Schema for Esplustodo

DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS members;

CREATE TABLE members (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  avatar TEXT,
  color TEXT NOT NULL DEFAULT '#3b82f6',
  email TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  assignee_id TEXT,
  status TEXT NOT NULL DEFAULT 'todo', -- 'todo', 'in_progress', 'in_review', 'done'
  priority TEXT NOT NULL DEFAULT 'medium', -- 'urgent', 'high', 'medium', 'low'
  start_date TEXT,
  due_date TEXT,
  tags TEXT DEFAULT '[]', -- JSON string of tags
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assignee_id) REFERENCES members(id) ON DELETE SET NULL
);

-- Seed Members
INSERT INTO members (id, name, role, avatar, color, email) VALUES
('m-1', 'สมชาย วงศ์สวัสดิ์', 'Lead Developer', '👨‍💻', '#3b82f6', 'somchai@company.com'),
('m-2', 'กัญญา รัตนพงษ์', 'UI/UX Designer', '🎨', '#ec4899', 'kanya@company.com'),
('m-3', 'อานนท์ ฤทธิรงค์', 'Frontend Developer', '⚡', '#10b981', 'anon@company.com'),
('m-4', 'สุภาพร นามดี', 'QA & Project Manager', '📋', '#f59e0b', 'supaporn@company.com');

-- Seed Tasks
INSERT INTO tasks (id, title, description, assignee_id, status, priority, start_date, due_date, tags) VALUES
('t-1', 'ออกแบบ Wireframe หน้า Dashboard ใหม่', 'ออกแบบ layout หน้าภาพรวมทีมให้ดูง่าย รองรับทั้ง desktop และ mobile', 'm-2', 'done', 'high', '2026-11-01', '2026-11-05', '["Design", "UI/UX"]'),
('t-2', 'เชื่อมต่อ Cloudflare D1 Database', 'ตั้งค่า schema และทดสอบเขียน-อ่านข้อมูลผ่าน Cloudflare Pages Functions', 'm-1', 'in_progress', 'urgent', '2026-11-04', '2026-11-08', '["Backend", "Cloudflare"]'),
('t-3', 'พัฒนา Component สำหรับ Kanban Board', 'ทำฟังก์ชัน Drag & Drop สำหรับย้ายการ์ดงานระหว่างคอลัมน์', 'm-3', 'in_progress', 'high', '2026-11-05', '2026-11-09', '["Frontend", "React"]'),
('t-4', 'ทดสอบระบบเปลี่ยนสถานะและ Deadline Alert', 'เขียน Test cases ตรวจสอบการแจ้งเตือนงานที่ใกล้ถึงกำหนดส่งและเลยกำหนด', 'm-4', 'todo', 'medium', '2026-11-07', '2026-11-12', '["QA", "Testing"]'),
('t-5', 'ปรับแต่ง UI Color Scheme ให้รองรับ Dark Mode', 'ทำ theme สีให้สบายตาและสามารถสลับโหมดได้', 'm-2', 'in_review', 'low', '2026-11-02', '2026-11-07', '["Design", "CSS"]'),
('t-6', 'จัดทำเอกสารคู่มือการใช้งานระบบทีม', 'เขียนสรุปวิธีการสร้างงาน ย้ายสถานะ และการสลับหน้าสมาชิกสำหรับทีมงาน', 'm-4', 'todo', 'low', '2026-11-08', '2026-11-15', '["Docs"]');
