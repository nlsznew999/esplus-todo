// Storage abstraction layer
// Automatically switches between API (/api/...) and LocalStorage fallback

const Storage = {
  isApiAvailable: false,
  storageKeyMembers: 'esplus_members',
  storageKeyTasks: 'esplus_tasks',

  async init() {
    // Check if API is available
    try {
      if (window.location.protocol === 'file:') {
        this.isApiAvailable = false;
      } else {
        const res = await fetch('/api/members', { method: 'GET' });
        if (res.ok) {
          this.isApiAvailable = true;
          console.log('Connected to Backend API (Cloudflare Pages / Local Server)');
          return;
        }
      }
    } catch (e) {
      this.isApiAvailable = false;
    }

    console.log('Running in LocalStorage Mode (Browser Storage)');
    // Seed LocalStorage if empty
    if (!localStorage.getItem(this.storageKeyMembers)) {
      localStorage.setItem(this.storageKeyMembers, JSON.stringify(window.DEFAULT_MEMBERS || []));
    }
    if (!localStorage.getItem(this.storageKeyTasks)) {
      localStorage.setItem(this.storageKeyTasks, JSON.stringify(window.DEFAULT_TASKS || []));
    }
  },

  // Members API
  async getMembers() {
    if (this.isApiAvailable) {
      try {
        const res = await fetch('/api/members');
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error, falling back to LocalStorage', e);
      }
    }
    const data = localStorage.getItem(this.storageKeyMembers);
    return data ? JSON.parse(data) : (window.DEFAULT_MEMBERS || []);
  },

  async saveMember(member) {
    if (this.isApiAvailable) {
      try {
        const isUpdate = !!member.id;
        const res = await fetch('/api/members', {
          method: isUpdate ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(member)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error during saveMember', e);
      }
    }

    // LocalStorage fallback
    let members = await this.getMembers();
    if (!member.id) {
      member.id = 'm-' + Date.now();
      members.push(member);
    } else {
      const idx = members.findIndex(m => m.id === member.id);
      if (idx !== -1) members[idx] = { ...members[idx], ...member };
      else members.push(member);
    }
    localStorage.setItem(this.storageKeyMembers, JSON.stringify(members));
    return { success: true, member };
  },

  async deleteMember(id) {
    if (this.isApiAvailable) {
      try {
        const res = await fetch(`/api/members?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error during deleteMember', e);
      }
    }

    // LocalStorage fallback
    let members = await this.getMembers();
    members = members.filter(m => m.id !== id);
    localStorage.setItem(this.storageKeyMembers, JSON.stringify(members));

    // Also unassign tasks
    let tasks = await this.getTasks();
    tasks = tasks.map(t => t.assignee_id === id ? { ...t, assignee_id: null } : t);
    localStorage.setItem(this.storageKeyTasks, JSON.stringify(tasks));

    return { success: true, deletedId: id };
  },

  // Tasks API
  async getTasks() {
    if (this.isApiAvailable) {
      try {
        const res = await fetch('/api/tasks');
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error, falling back to LocalStorage', e);
      }
    }
    const data = localStorage.getItem(this.storageKeyTasks);
    return data ? JSON.parse(data) : (window.DEFAULT_TASKS || []);
  },

  async saveTask(task) {
    if (this.isApiAvailable) {
      try {
        const isUpdate = !!task.id;
        const res = await fetch('/api/tasks', {
          method: isUpdate ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(task)
        });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error during saveTask', e);
      }
    }

    // LocalStorage fallback
    let tasks = await this.getTasks();
    const now = new Date().toISOString();
    if (!task.id) {
      task.id = 't-' + Date.now();
      task.created_at = now;
      task.updated_at = now;
      tasks.unshift(task);
    } else {
      const idx = tasks.findIndex(t => t.id === task.id);
      if (idx !== -1) {
        task.updated_at = now;
        tasks[idx] = { ...tasks[idx], ...task };
      } else {
        tasks.unshift(task);
      }
    }
    localStorage.setItem(this.storageKeyTasks, JSON.stringify(tasks));
    return { success: true, task };
  },

  async updateTaskStatus(taskId, newStatus) {
    return await this.saveTask({ id: taskId, status: newStatus });
  },

  async deleteTask(id) {
    if (this.isApiAvailable) {
      try {
        const res = await fetch(`/api/tasks?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
        if (res.ok) return await res.json();
      } catch (e) {
        console.warn('API error during deleteTask', e);
      }
    }

    let tasks = await this.getTasks();
    tasks = tasks.filter(t => t.id !== id);
    localStorage.setItem(this.storageKeyTasks, JSON.stringify(tasks));
    return { success: true, deletedId: id };
  },

  // Backup & Restore
  async exportBackup() {
    const members = await this.getMembers();
    const tasks = await this.getTasks();
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      members,
      tasks
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `esplus-todo-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  },

  async importBackup(jsonData) {
    try {
      const parsed = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
      if (Array.isArray(parsed.members) && Array.isArray(parsed.tasks)) {
        localStorage.setItem(this.storageKeyMembers, JSON.stringify(parsed.members));
        localStorage.setItem(this.storageKeyTasks, JSON.stringify(parsed.tasks));
        return true;
      }
      return false;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  }
};

window.Storage = Storage;
