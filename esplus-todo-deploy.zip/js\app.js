// Main Application Controller for Esplustodo

const App = {
  tasks: [],
  members: [],
  currentView: 'overview', // 'overview' | 'member'
  currentMemberId: null,
  overviewTab: 'dashboard', // 'dashboard' | 'kanban'
  filterText: '',
  filterPriority: 'all',
  filterAssignee: 'all',

  async init() {
    this.initTheme();
    await Storage.init();
    await this.refreshData();
    this.setupEventListeners();
    this.render();

    // Check URL hash for routing
    window.addEventListener('hashchange', () => this.handleHashChange());
    this.handleHashChange();
  },

  initTheme() {
    const savedTheme = localStorage.getItem('esplus_theme') || 'light';
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  },

  toggleTheme() {
    const isDark = document.documentElement.classList.toggle('dark');
    localStorage.setItem('esplus_theme', isDark ? 'dark' : 'light');
    this.showToast(isDark ? 'เปิดใช้งานโหมดมืด (Dark Mode)' : 'เปิดใช้งานโหมดสว่าง (Light Mode)');
  },

  async refreshData() {
    this.members = await Storage.getMembers();
    this.tasks = await Storage.getTasks();
  },

  handleHashChange() {
    const hash = window.location.hash;
    if (hash.startsWith('#/member/')) {
      const memberId = hash.replace('#/member/', '');
      this.switchView('member', memberId, false);
    } else {
      this.switchView('overview', null, false);
    }
  },

  switchView(view, memberId = null, updateHash = true) {
    this.currentView = view;
    this.currentMemberId = memberId;
    if (updateHash) {
      if (view === 'member' && memberId) {
        window.location.hash = `#/member/${memberId}`;
      } else {
        window.location.hash = '#/';
      }
    }
    this.render();
  },

  setOverviewTab(tab) {
    this.overviewTab = tab;
    this.render();
  },

  setupEventListeners() {
    // Quick search bar input
    const searchInput = document.getElementById('global-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.filterText = e.target.value;
        this.renderCurrentViewContent();
      });
    }

    // Priority filter select
    const prioritySelect = document.getElementById('filter-priority');
    if (prioritySelect) {
      prioritySelect.addEventListener('change', (e) => {
        this.filterPriority = e.target.value;
        this.renderCurrentViewContent();
      });
    }

    // Assignee filter select (Master Kanban)
    const assigneeSelect = document.getElementById('filter-assignee');
    if (assigneeSelect) {
      assigneeSelect.addEventListener('change', (e) => {
        this.filterAssignee = e.target.value;
        this.renderCurrentViewContent();
      });
    }
  },

  // Main Render Routine
  render() {
    this.renderProfileSwitcher();
    this.renderNavPills();
    this.renderCurrentViewContent();
  },

  // Top Profile Switcher Dropdown
  renderProfileSwitcher() {
    const container = document.getElementById('profile-switcher-container');
    if (!container) return;

    const currentMember = this.members.find(m => m.id === this.currentMemberId);

    container.innerHTML = `
      <div class="relative inline-block text-left" id="profile-dropdown-wrapper">
        <button 
          id="profile-dropdown-btn"
          onclick="App.toggleProfileDropdown()" 
          class="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm hover:border-blue-400 dark:hover:border-blue-500 transition-all text-sm font-medium text-slate-700 dark:text-slate-200"
        >
          ${this.currentView === 'overview' ? `
            <span class="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center text-xs">👥</span>
            <span>ภาพรวมทั้งทีม (Overview)</span>
          ` : `
            <span class="w-6 h-6 rounded-lg flex items-center justify-center text-xs text-white" style="background-color: ${currentMember?.color || '#3b82f6'}">
              ${currentMember?.avatar || '👤'}
            </span>
            <span class="font-semibold text-blue-600 dark:text-blue-400">${currentMember?.name || 'สมาชิก'}</span>
            <span class="text-xs text-slate-400 dark:text-slate-500 font-normal">(${currentMember?.role || ''})</span>
          `}
          <svg class="w-4 h-4 text-slate-400 ml-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
          </svg>
        </button>

        <!-- Dropdown Menu -->
        <div 
          id="profile-dropdown-menu" 
          class="hidden absolute right-0 mt-2 w-72 rounded-2xl bg-white dark:bg-slate-800 shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
        >
          <div class="px-3 py-1.5 text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            เลือกมุมมองการทำงาน
          </div>

          <!-- Overview Option -->
          <button 
            onclick="App.switchView('overview'); App.toggleProfileDropdown();"
            class="w-full flex items-center gap-3 px-3 py-2.5 text-left text-sm hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors ${this.currentView === 'overview' ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-700 dark:text-slate-300'}"
          >
            <span class="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center text-sm shadow-sm">👥</span>
            <div>
              <div class="leading-tight">ภาพรวมทีม (Overview)</div>
              <div class="text-[11px] text-slate-400 font-normal">ดูสถิติและงานของทุกคนในทีม</div>
            </div>
          </button>

          <div class="my-1 border-t border-slate-100 dark:border-slate-700"></div>
          <div class="px-3 py-1 text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
            สมาชิกในทีม (บอร์ดส่วนตัว)
          </div>

          <!-- Members List -->
          <div class="max-h-60 overflow-y-auto">
            ${this.members.map(m => {
              const memberTasks = this.tasks.filter(t => t.assignee_id === m.id);
              const pendingCount = memberTasks.filter(t => t.status !== 'done').length;
              const isSelected = this.currentView === 'member' && this.currentMemberId === m.id;
              return `
                <button 
                  onclick="App.switchView('member', '${m.id}'); App.toggleProfileDropdown();"
                  class="w-full flex items-center justify-between px-3 py-2 text-left text-sm hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors ${isSelected ? 'bg-blue-50 dark:bg-blue-900/30 font-semibold' : 'text-slate-700 dark:text-slate-300'}"
                >
                  <div class="flex items-center gap-2.5 min-w-0">
                    <span class="w-7 h-7 rounded-xl flex items-center justify-center text-xs text-white shadow-sm flex-shrink-0" style="background-color: ${m.color}">
                      ${m.avatar}
                    </span>
                    <div class="truncate">
                      <div class="text-sm truncate leading-tight ${isSelected ? 'text-blue-600 dark:text-blue-400' : ''}">${m.name}</div>
                      <div class="text-[11px] text-slate-400 truncate">${m.role}</div>
                    </div>
                  </div>
                  <span class="px-2 py-0.5 rounded-full text-[11px] font-medium ${pendingCount > 0 ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}">
                    ${pendingCount} งาน
                  </span>
                </button>
              `;
            }).join('')}
          </div>

          <div class="my-1 border-t border-slate-100 dark:border-slate-700"></div>
          <button 
            onclick="App.openManageTeamModal(); App.toggleProfileDropdown();"
            class="w-full flex items-center gap-2 px-3 py-2 text-left text-xs font-medium text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 transition-colors"
          >
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            จัดการสมาชิกในทีม (+ เพิ่ม/แก้ไข)
          </button>
        </div>
      </div>
    `;
  },

  toggleProfileDropdown() {
    const menu = document.getElementById('profile-dropdown-menu');
    if (menu) menu.classList.toggle('hidden');
  },

  // Close dropdown on outside click
  closeProfileDropdownOnOutside(e) {
    const wrapper = document.getElementById('profile-dropdown-wrapper');
    const menu = document.getElementById('profile-dropdown-menu');
    if (wrapper && menu && !wrapper.contains(e.target)) {
      menu.classList.add('hidden');
    }
  },

  // Render Subnav Pills (Overview tabs or Member board banner)
  renderNavPills() {
    const container = document.getElementById('nav-pills-container');
    if (!container) return;

    if (this.currentView === 'overview') {
      container.innerHTML = `
        <div class="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          <button 
            onclick="App.setOverviewTab('dashboard')"
            class="flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${this.overviewTab === 'dashboard' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'}"
          >
            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
            ภาพรวม & สถิติ (Dashboard)
          </button>
          <button 
            onclick="App.setOverviewTab('kanban')"
            class="flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${this.overviewTab === 'kanban' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'}"
          >
            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"/></svg>
            Master Kanban Board (งานทั้งทีม)
          </button>
        </div>
      `;
    } else {
      const member = this.members.find(m => m.id === this.currentMemberId);
      container.innerHTML = `
        <div class="flex items-center gap-2 text-xs">
          <button 
            onclick="App.switchView('overview')"
            class="flex items-center gap-1 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition-colors"
          >
            <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            กลับสู่ภาพรวมทีม
          </button>
          <span class="text-slate-300 dark:text-slate-600">/</span>
          <span class="text-slate-900 dark:text-white font-semibold">บอร์ดส่วนตัวของ ${member?.name || ''}</span>
        </div>
      `;
    }
  },

  // Render Active View Content
  renderCurrentViewContent() {
    const mainContainer = document.getElementById('main-content-view');
    if (!mainContainer) return;

    if (this.currentView === 'overview') {
      if (this.overviewTab === 'dashboard') {
        this.renderOverviewDashboard(mainContainer);
      } else {
        this.renderMasterKanbanView(mainContainer);
      }
    } else {
      this.renderMemberView(mainContainer);
    }
  },

  // 1. Overview Dashboard (Metrics, Workload, Approaching Deadlines)
  renderOverviewDashboard(container) {
    const total = this.tasks.length;
    const inProgress = this.tasks.filter(t => t.status === 'in_progress').length;
    const inReview = this.tasks.filter(t => t.status === 'in_review').length;
    const done = this.tasks.filter(t => t.status === 'done').length;
    const todo = this.tasks.filter(t => t.status === 'todo').length;

    // Overdue tasks
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const overdueTasks = this.tasks.filter(t => {
      if (t.status === 'done' || !t.due_date) return false;
      const due = new Date(t.due_date);
      due.setHours(0, 0, 0, 0);
      return due < now;
    });

    // Upcoming deadlines (next 7 days)
    const upcomingDeadlines = this.tasks
      .filter(t => t.status !== 'done' && t.due_date)
      .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
      .slice(0, 5);

    const memberMap = new Map(this.members.map(m => [m.id, m]));

    container.innerHTML = `
      <div class="space-y-6">
        <!-- Top Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <!-- Total Tasks -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
            <div>
              <p class="text-xs font-medium text-slate-500 dark:text-slate-400">งานทั้งหมดในระบบ</p>
              <h3 class="text-3xl font-extrabold text-slate-900 dark:text-white mt-1">${total}</h3>
              <p class="text-[11px] text-slate-400 mt-1">รอดำเนินการ ${todo} งาน</p>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center text-xl">
              📊
            </div>
          </div>

          <!-- In Progress -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
            <div>
              <p class="text-xs font-medium text-slate-500 dark:text-slate-400">กำลังดำเนินการ</p>
              <h3 class="text-3xl font-extrabold text-blue-600 dark:text-blue-400 mt-1">${inProgress}</h3>
              <p class="text-[11px] text-amber-500 mt-1">รอตรวจสอบ ${inReview} งาน</p>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center text-xl">
              ⚡
            </div>
          </div>

          <!-- Completed -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
            <div>
              <p class="text-xs font-medium text-slate-500 dark:text-slate-400">เสร็จสิ้นแล้ว</p>
              <h3 class="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1">${done}</h3>
              <p class="text-[11px] text-emerald-500 mt-1">${total > 0 ? Math.round((done / total) * 100) : 0}% ของงานทั้งหมด</p>
            </div>
            <div class="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-xl">
              ✅
            </div>
          </div>

          <!-- Overdue Alert -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex items-center justify-between">
            <div>
              <p class="text-xs font-medium text-slate-500 dark:text-slate-400">งานที่เลยกำหนดส่ง</p>
              <h3 class="text-3xl font-extrabold ${overdueTasks.length > 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-900 dark:text-white'} mt-1">${overdueTasks.length}</h3>
              <p class="text-[11px] ${overdueTasks.length > 0 ? 'text-red-500 font-medium' : 'text-slate-400'} mt-1">
                ${overdueTasks.length > 0 ? 'ต้องเร่งดำเนินการ!' : 'ยอดเยี่ยม ไม่มีงานค้างส่ง'}
              </p>
            </div>
            <div class="w-12 h-12 rounded-2xl ${overdueTasks.length > 0 ? 'bg-red-50 dark:bg-red-900/30 text-red-600' : 'bg-slate-50 dark:bg-slate-700/40 text-slate-400'} flex items-center justify-center text-xl">
              ⏰
            </div>
          </div>
        </div>

        <!-- Middle Section: Team Members Workload Grid -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
          <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-700/60 mb-5 gap-3">
            <div>
              <h3 class="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>ภาระงานของทีมงานแต่ละคน (Workload Summary)</span>
                <span class="text-xs font-normal text-slate-400">คลิกที่การ์ดเพื่อเปิดบอร์ดเฉพาะคน</span>
              </h3>
              <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">ภาพรวมการกระจายงานและความคืบหน้าของทุกคนในทีม</p>
            </div>
            
            <button 
              onclick="App.openManageTeamModal()"
              class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-500 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all"
            >
              <svg class="w-3.5 h-3.5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
              เพิ่ม / จัดการสมาชิก
            </button>
          </div>

          <!-- Members Workload Cards -->
          <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            ${this.members.map(member => {
              const mTasks = this.tasks.filter(t => t.assignee_id === member.id);
              const mTotal = mTasks.length;
              const mDone = mTasks.filter(t => t.status === 'done').length;
              const mInProgress = mTasks.filter(t => t.status === 'in_progress').length;
              const mReview = mTasks.filter(t => t.status === 'in_review').length;
              const mTodo = mTasks.filter(t => t.status === 'todo').length;
              const percent = mTotal > 0 ? Math.round((mDone / mTotal) * 100) : 0;

              return `
                <div 
                  onclick="App.switchView('member', '${member.id}')"
                  class="group relative bg-slate-50/80 dark:bg-slate-900/50 hover:bg-blue-50/40 dark:hover:bg-blue-950/20 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-400 dark:hover:border-blue-500 rounded-2xl p-4 transition-all duration-200 cursor-pointer shadow-sm hover:shadow"
                >
                  <!-- Member Header -->
                  <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center gap-2.5">
                      <span class="w-9 h-9 rounded-xl flex items-center justify-center text-sm text-white shadow-sm" style="background-color: ${member.color}">
                        ${member.avatar}
                      </span>
                      <div>
                        <h4 class="font-bold text-slate-900 dark:text-white text-sm group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          ${member.name}
                        </h4>
                        <p class="text-[11px] text-slate-400">${member.role}</p>
                      </div>
                    </div>

                    <span class="text-xs font-bold text-slate-700 dark:text-slate-300">
                      ${mTotal} งาน
                    </span>
                  </div>

                  <!-- Progress Bar -->
                  <div class="space-y-1.5 mb-3">
                    <div class="flex justify-between text-[11px]">
                      <span class="text-slate-500">ความสำเร็จ</span>
                      <span class="font-semibold text-slate-700 dark:text-slate-300">${percent}%</span>
                    </div>
                    <div class="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden flex">
                      <div class="h-full bg-emerald-500 transition-all duration-300" style="width: ${percent}%"></div>
                    </div>
                  </div>

                  <!-- Mini Status Breakdown -->
                  <div class="grid grid-cols-4 gap-1 text-center pt-2 border-t border-slate-200/60 dark:border-slate-800 text-[11px]">
                    <div class="bg-white dark:bg-slate-800/80 rounded py-1">
                      <div class="text-slate-400 text-[10px]">รอทำ</div>
                      <div class="font-bold text-slate-700 dark:text-slate-300">${mTodo}</div>
                    </div>
                    <div class="bg-blue-50 dark:bg-blue-900/30 rounded py-1">
                      <div class="text-blue-500 text-[10px]">กำลังทำ</div>
                      <div class="font-bold text-blue-700 dark:text-blue-300">${mInProgress}</div>
                    </div>
                    <div class="bg-amber-50 dark:bg-amber-900/30 rounded py-1">
                      <div class="text-amber-500 text-[10px]">รอตรวจ</div>
                      <div class="font-bold text-amber-700 dark:text-amber-300">${mReview}</div>
                    </div>
                    <div class="bg-emerald-50 dark:bg-emerald-900/30 rounded py-1">
                      <div class="text-emerald-500 text-[10px]">เสร็จ</div>
                      <div class="font-bold text-emerald-700 dark:text-emerald-300">${mDone}</div>
                    </div>
                  </div>

                  <!-- Hover link pill -->
                  <div class="mt-3 text-right">
                    <span class="text-[11px] font-semibold text-blue-600 dark:text-blue-400 group-hover:underline inline-flex items-center gap-1">
                      เปิด Kanban บอร์ด
                      <svg class="w-3 h-3 transition-transform group-hover:translate-x-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
                    </span>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Bottom Grid: Approaching Deadlines & Fast Actions -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Upcoming Deadlines (2 cols) -->
          <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-700/80 shadow-sm">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700/60 mb-4">
              <h3 class="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>⏰ กำหนดส่งที่ใกล้จะถึง (Upcoming Deadlines)</span>
              </h3>
              <button 
                onclick="App.setOverviewTab('kanban')"
                class="text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium"
              >
                ดูทั้งหมดใน Kanban →
              </button>
            </div>

            <div class="space-y-2.5">
              ${upcomingDeadlines.length > 0 ? upcomingDeadlines.map(task => {
                const assignee = memberMap.get(task.assignee_id);
                return `
                  <div 
                    onclick="App.openTaskDetailModal('${task.id}')"
                    class="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900/40 hover:bg-blue-50/50 dark:hover:bg-blue-950/20 border border-slate-100 dark:border-slate-800 transition-colors cursor-pointer"
                  >
                    <div class="flex items-center gap-3 min-w-0">
                      ${Kanban.getPriorityBadge(task.priority)}
                      <div class="truncate">
                        <div class="text-sm font-semibold text-slate-900 dark:text-white truncate">${task.title}</div>
                        <div class="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>ผู้รับผิดชอบ: ${assignee ? assignee.name : 'ยังไม่ระบุ'}</span>
                          <span>•</span>
                          <span>สถานะ: ${Kanban.columns.find(c => c.id === task.status)?.title}</span>
                        </div>
                      </div>
                    </div>

                    <div class="flex-shrink-0 text-right ml-4">
                      ${Kanban.getDeadlineBadge(task.due_date, task.status)}
                    </div>
                  </div>
                `;
              }).join('') : `
                <div class="text-center py-8 text-xs text-slate-400">
                  ไม่มีงานที่ค้างส่งในสัปดาห์นี้
                </div>
              `}
            </div>
          </div>

          <!-- Quick Actions & Cloudflare Info -->
          <div class="bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-2xl p-6 shadow-md flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between mb-4">
                <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-white/20 backdrop-blur-sm">
                  ☁️ Cloudflare Pages Ready
                </span>
                <span class="text-xs opacity-75">v1.0</span>
              </div>
              <h4 class="text-lg font-bold mb-2">ระบบจัดเก็บและเชื่อมต่อ</h4>
              <p class="text-xs text-blue-100 leading-relaxed mb-4">
                ระบบถูกออกแบบให้รองรับทั้ง <strong>Cloudflare D1</strong> (Database กลางออนไลน์) และโหมดทำงานในเครื่อง มีระบบส่งออกข้อมูล Backup แบบ JSON ครบวงจร
              </p>
            </div>

            <div class="space-y-2 pt-4 border-t border-white/10">
              <button 
                onclick="App.openCreateTaskModal()"
                class="w-full py-2.5 px-4 rounded-xl bg-white text-blue-600 font-bold text-xs shadow hover:bg-blue-50 transition-all flex items-center justify-center gap-2"
              >
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                สร้างงานใหม่ให้สมาชิกในทีม
              </button>
              
              <div class="grid grid-cols-2 gap-2">
                <button 
                  onclick="Storage.exportBackup()"
                  class="py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium transition-colors text-center"
                >
                  📥 ส่งออก JSON
                </button>
                <button 
                  onclick="App.openImportModal()"
                  class="py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium transition-colors text-center"
                >
                  📤 นำเข้าข้อมูล
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // 2. Master Kanban Board View (All Team Tasks)
  renderMasterKanbanView(container) {
    container.innerHTML = `
      <div class="space-y-4">
        <!-- Master Filter Bar -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex flex-wrap items-center justify-between gap-3">
          <div class="flex flex-wrap items-center gap-3">
            <span class="text-xs font-bold text-slate-700 dark:text-slate-300">ตัวกรองบอร์ด:</span>
            
            <!-- Assignee Filter -->
            <select 
              id="filter-assignee"
              onchange="App.handleAssigneeFilterChange(this.value)"
              class="px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="all">👥 สมาชิกทุกคน (${this.tasks.length} งาน)</option>
              ${this.members.map(m => `
                <option value="${m.id}" ${this.filterAssignee === m.id ? 'selected' : ''}>
                  ${m.name} (${this.tasks.filter(t => t.assignee_id === m.id).length})
                </option>
              `).join('')}
            </select>

            <!-- Priority Filter -->
            <select 
              id="filter-priority"
              onchange="App.handlePriorityFilterChange(this.value)"
              class="px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="all" ${this.filterPriority === 'all' ? 'selected' : ''}>🎯 ทุกระดับความสำคัญ</option>
              <option value="urgent" ${this.filterPriority === 'urgent' ? 'selected' : ''}>🔴 ด่วนมาก (Urgent)</option>
              <option value="high" ${this.filterPriority === 'high' ? 'selected' : ''}>🟠 สูง (High)</option>
              <option value="medium" ${this.filterPriority === 'medium' ? 'selected' : ''}>🔵 ปานกลาง (Medium)</option>
              <option value="low" ${this.filterPriority === 'low' ? 'selected' : ''}>⚪ ทั่วไป (Low)</option>
            </select>
          </div>

          <button 
            onclick="App.openCreateTaskModal()"
            class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition-all flex items-center gap-2"
          >
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            เพิ่มงานใหม่
          </button>
        </div>

        <!-- Kanban Board Container -->
        <div id="kanban-board-container" class="overflow-x-auto pb-4">
          ${Kanban.renderBoard(
            this.tasks,
            this.members,
            this.filterAssignee === 'all' ? null : this.filterAssignee,
            this.filterText,
            this.filterPriority
          )}
        </div>
      </div>
    `;

    Kanban.bindCardDragEvents('#kanban-board-container');
    Kanban.initDragAndDrop('#kanban-board-container', (taskId, newStatus) => this.handleTaskDrop(taskId, newStatus));
  },

  handleAssigneeFilterChange(val) {
    this.filterAssignee = val;
    this.renderCurrentViewContent();
  },

  handlePriorityFilterChange(val) {
    this.filterPriority = val;
    this.renderCurrentViewContent();
  },

  // 3. Member-Specific Kanban View (หน้าของทีมงานแต่ละคน)
  renderMemberView(container) {
    const member = this.members.find(m => m.id === this.currentMemberId);
    if (!member) {
      this.switchView('overview');
      return;
    }

    const memberTasks = this.tasks.filter(t => t.assignee_id === member.id);
    const mTotal = memberTasks.length;
    const mDone = memberTasks.filter(t => t.status === 'done').length;
    const mInProgress = memberTasks.filter(t => t.status === 'in_progress').length;
    const mReview = memberTasks.filter(t => t.status === 'in_review').length;
    const mTodo = memberTasks.filter(t => t.status === 'todo').length;
    const percent = mTotal > 0 ? Math.round((mDone / mTotal) * 100) : 0;

    container.innerHTML = `
      <div class="space-y-5">
        <!-- Member Profile Header Banner -->
        <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-700/80 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div class="flex items-center gap-4">
            <span class="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl text-white shadow-md flex-shrink-0" style="background-color: ${member.color}">
              ${member.avatar}
            </span>
            <div>
              <div class="flex items-center gap-2">
                <h2 class="text-xl font-extrabold text-slate-900 dark:text-white">${member.name}</h2>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400">
                  ${member.role}
                </span>
              </div>
              <p class="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
                ${member.email ? `<span>✉️ ${member.email}</span> <span>•</span>` : ''}
                <span>งานทั้งหมดในความรับผิดชอบ ${mTotal} งาน</span>
              </p>
            </div>
          </div>

          <!-- Quick stats badges -->
          <div class="flex items-center gap-3 flex-wrap">
            <div class="bg-slate-50 dark:bg-slate-900/60 rounded-xl px-3.5 py-2 border border-slate-100 dark:border-slate-700/60 text-center">
              <div class="text-[10px] text-slate-400 uppercase font-semibold">ความคืบหน้า</div>
              <div class="text-base font-extrabold text-blue-600 dark:text-blue-400">${percent}%</div>
            </div>
            <div class="bg-slate-50 dark:bg-slate-900/60 rounded-xl px-3.5 py-2 border border-slate-100 dark:border-slate-700/60 text-center">
              <div class="text-[10px] text-slate-400 uppercase font-semibold">กำลังทำ</div>
              <div class="text-base font-extrabold text-blue-500">${mInProgress}</div>
            </div>
            <div class="bg-slate-50 dark:bg-slate-900/60 rounded-xl px-3.5 py-2 border border-slate-100 dark:border-slate-700/60 text-center">
              <div class="text-[10px] text-slate-400 uppercase font-semibold">เสร็จสิ้น</div>
              <div class="text-base font-extrabold text-emerald-600">${mDone}</div>
            </div>
            
            <button 
              onclick="App.openCreateTaskModal('todo', '${member.id}')"
              class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow transition-all flex items-center gap-1.5"
            >
              <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
              + เพิ่มงานให้ ${member.name.split(' ')[0]}
            </button>
          </div>
        </div>

        <!-- Personal Kanban Board -->
        <div id="member-kanban-container" class="overflow-x-auto pb-4">
          ${Kanban.renderBoard(
            this.tasks,
            this.members,
            member.id,
            this.filterText,
            this.filterPriority
          )}
        </div>
      </div>
    `;

    Kanban.bindCardDragEvents('#member-kanban-container');
    Kanban.initDragAndDrop('#member-kanban-container', (taskId, newStatus) => this.handleTaskDrop(taskId, newStatus));
  },

  // Drag and Drop Handler
  async handleTaskDrop(taskId, newStatus) {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task || task.status === newStatus) return;

    const oldStatus = task.status;
    task.status = newStatus;
    
    // Quick optimism update
    this.renderCurrentViewContent();

    try {
      await Storage.updateTaskStatus(taskId, newStatus);
      const colTitle = Kanban.columns.find(c => c.id === newStatus)?.title;
      this.showToast(`ย้ายงาน "${task.title.substring(0, 20)}..." ไปที่ ${colTitle} แล้ว`);
    } catch (e) {
      console.error(e);
      task.status = oldStatus;
      this.renderCurrentViewContent();
      this.showToast('เกิดข้อผิดพลาดในการเปลี่ยนสถานะ', 'error');
    }
  },

  // Modal: Create or Edit Task
  openCreateTaskModal(status = 'todo', assigneeId = '') {
    this.openTaskFormModal(null, status, assigneeId);
  },

  openEditTaskModal(taskId) {
    const task = this.tasks.find(t => t.id === taskId);
    if (task) this.openTaskFormModal(task);
  },

  openTaskFormModal(task = null, defaultStatus = 'todo', defaultAssigneeId = '') {
    const modal = document.getElementById('task-modal');
    const modalTitle = document.getElementById('task-modal-title');
    const form = document.getElementById('task-form');
    if (!modal || !form) return;

    const isEdit = !!task;
    modalTitle.textContent = isEdit ? 'แก้ไขงาน (Edit Task)' : 'สร้างงานใหม่ (New Task)';

    document.getElementById('task-id').value = isEdit ? task.id : '';
    document.getElementById('task-title').value = isEdit ? task.title : '';
    document.getElementById('task-description').value = isEdit ? (task.description || '') : '';
    document.getElementById('task-status').value = isEdit ? task.status : defaultStatus;
    document.getElementById('task-priority').value = isEdit ? task.priority : 'medium';
    document.getElementById('task-due-date').value = isEdit ? (task.due_date || '') : '';
    document.getElementById('task-tags').value = isEdit ? (task.tags || []).join(', ') : '';

    // Assignee select options
    const assigneeSelect = document.getElementById('task-assignee');
    const targetAssigneeId = isEdit ? task.assignee_id : (defaultAssigneeId || this.currentMemberId || '');

    assigneeSelect.innerHTML = `
      <option value="">-- ยังไม่มอบหมายให้ใคร --</option>
      ${this.members.map(m => `
        <option value="${m.id}" ${targetAssigneeId === m.id ? 'selected' : ''}>
          ${m.avatar} ${m.name} (${m.role})
        </option>
      `).join('')}
    `;

    modal.classList.remove('hidden');
    document.getElementById('task-title').focus();
  },

  closeTaskModal() {
    const modal = document.getElementById('task-modal');
    if (modal) modal.classList.add('hidden');
  },

  async handleTaskFormSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('task-id').value;
    const title = document.getElementById('task-title').value.trim();
    const description = document.getElementById('task-description').value.trim();
    const status = document.getElementById('task-status').value;
    const priority = document.getElementById('task-priority').value;
    const assignee_id = document.getElementById('task-assignee').value || null;
    const due_date = document.getElementById('task-due-date').value || null;
    const tagsRaw = document.getElementById('task-tags').value;
    const tags = tagsRaw ? tagsRaw.split(',').map(s => s.trim()).filter(Boolean) : [];

    if (!title) {
      alert('กรุณาระบุชื่องาน');
      return;
    }

    const taskData = {
      title,
      description,
      status,
      priority,
      assignee_id,
      due_date,
      tags
    };

    if (id) taskData.id = id;

    await Storage.saveTask(taskData);
    await this.refreshData();
    this.closeTaskModal();
    this.render();
    this.showToast(id ? 'บันทึกการแก้ไขงานเรียบร้อย' : 'สร้างงานใหม่เรียบร้อยแล้ว');
  },

  // Modal: View Task Details
  openTaskDetailModal(taskId) {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return;

    const modal = document.getElementById('task-detail-modal');
    const container = document.getElementById('task-detail-content');
    if (!modal || !container) return;

    const member = this.members.find(m => m.id === task.assignee_id);
    const col = Kanban.columns.find(c => c.id === task.status);

    container.innerHTML = `
      <div class="space-y-4">
        <!-- Status & Priority Badges -->
        <div class="flex items-center justify-between flex-wrap gap-2">
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-1 rounded-full text-xs font-semibold ${col?.badge}">
              ${col?.title} (${col?.subtitle})
            </span>
            ${Kanban.getPriorityBadge(task.priority)}
          </div>
          <div>
            ${Kanban.getDeadlineBadge(task.due_date, task.status)}
          </div>
        </div>

        <!-- Task Title -->
        <h3 class="text-xl font-bold text-slate-900 dark:text-white leading-snug">
          ${task.title}
        </h3>

        <!-- Description -->
        <div class="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800 text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
          ${task.description || '<span class="text-slate-400 italic">ไม่มีรายละเอียดเพิ่มเติม</span>'}
        </div>

        <!-- Metadata Info -->
        <div class="grid grid-cols-2 gap-4 py-2 border-y border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <div class="text-slate-400 mb-1">ผู้รับผิดชอบ</div>
            <div class="flex items-center gap-2">
              <span class="w-6 h-6 rounded-full flex items-center justify-center text-xs text-white" style="background-color: ${member?.color || '#94a3b8'}">
                ${member?.avatar || '👤'}
              </span>
              <span class="font-medium text-slate-900 dark:text-white">${member ? member.name : 'ยังไม่ระบุ'}</span>
            </div>
          </div>
          <div>
            <div class="text-slate-400 mb-1">วันที่สร้าง / อัปเดตล่าสุด</div>
            <div class="text-slate-700 dark:text-slate-300">
              ${task.created_at ? task.created_at.split('T')[0] : '-'}
            </div>
          </div>
        </div>

        <!-- Tags -->
        ${(task.tags && task.tags.length > 0) ? `
          <div class="flex flex-wrap gap-1.5 pt-1">
            ${task.tags.map(t => `<span class="px-2 py-0.5 rounded text-xs bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">#${t}</span>`).join('')}
          </div>
        ` : ''}

        <!-- Actions -->
        <div class="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button 
            onclick="App.closeTaskDetailModal(); App.openEditTaskModal('${task.id}')"
            class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-sm transition-all"
          >
            ✏️ แก้ไขงานนี้
          </button>
        </div>
      </div>
    `;

    modal.classList.remove('hidden');
  },

  closeTaskDetailModal() {
    const modal = document.getElementById('task-detail-modal');
    if (modal) modal.classList.add('hidden');
  },

  // Modal: Manage Team Members
  openManageTeamModal() {
    const modal = document.getElementById('team-modal');
    if (!modal) return;
    this.renderTeamMembersList();
    modal.classList.remove('hidden');
  },

  closeTeamModal() {
    const modal = document.getElementById('team-modal');
    if (modal) modal.classList.add('hidden');
  },

  renderTeamMembersList() {
    const container = document.getElementById('team-members-list');
    if (!container) return;

    container.innerHTML = this.members.map(m => {
      const taskCount = this.tasks.filter(t => t.assignee_id === m.id).length;
      return `
        <div class="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-800">
          <div class="flex items-center gap-3">
            <span class="w-9 h-9 rounded-xl flex items-center justify-center text-sm text-white shadow-sm" style="background-color: ${m.color}">
              ${m.avatar}
            </span>
            <div>
              <div class="text-sm font-bold text-slate-900 dark:text-white">${m.name}</div>
              <div class="text-xs text-slate-400">${m.role} • มี ${taskCount} งานในระบบ</div>
            </div>
          </div>

          <div class="flex items-center gap-1">
            <button 
              onclick="App.editMemberPrompt('${m.id}')" 
              class="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors"
              title="แก้ไขข้อมูล"
            >
              <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
            </button>
            <button 
              onclick="App.confirmDeleteMember('${m.id}')" 
              class="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/40 text-slate-400 hover:text-red-600 transition-colors"
              title="ลบสมาชิก"
            >
              <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </div>
      `;
    }).join('');
  },

  async handleAddMember(e) {
    e.preventDefault();
    const name = document.getElementById('new-member-name').value.trim();
    const role = document.getElementById('new-member-role').value.trim();
    const avatar = document.getElementById('new-member-avatar').value.trim() || '👤';
    const color = document.getElementById('new-member-color').value || '#3b82f6';
    const email = document.getElementById('new-member-email').value.trim();

    if (!name || !role) {
      alert('กรุณากรอกชื่อและตำแหน่งของสมาชิก');
      return;
    }

    await Storage.saveMember({ name, role, avatar, color, email });
    await this.refreshData();
    this.renderTeamMembersList();
    this.render();
    
    // Reset form
    document.getElementById('new-member-name').value = '';
    document.getElementById('new-member-role').value = '';
    document.getElementById('new-member-email').value = '';
    this.showToast(`เพิ่มสมาชิก "${name}" เรียบร้อยแล้ว`);
  },

  async editMemberPrompt(memberId) {
    const member = this.members.find(m => m.id === memberId);
    if (!member) return;

    const newName = prompt('แก้ไขชื่อสมาชิก:', member.name);
    if (!newName) return;
    const newRole = prompt('แก้ไขตำแหน่ง:', member.role) || member.role;
    const newAvatar = prompt('แก้ไขไอคอน/อิโมจิประจำตัว:', member.avatar) || member.avatar;

    await Storage.saveMember({
      ...member,
      name: newName.trim(),
      role: newRole.trim(),
      avatar: newAvatar.trim()
    });
    await this.refreshData();
    this.renderTeamMembersList();
    this.render();
    this.showToast('อัปเดตข้อมูลสมาชิกเรียบร้อย');
  },

  async confirmDeleteMember(memberId) {
    const member = this.members.find(m => m.id === memberId);
    if (!member) return;

    if (confirm(`คุณต้องการลบ "${member.name}" หรือไม่?\n(งานที่ได้รับมอบหมายจะถูกเปลี่ยนเป็น "ยังไม่ระบุผู้รับผิดชอบ")`)) {
      await Storage.deleteMember(memberId);
      if (this.currentMemberId === memberId) {
        this.switchView('overview');
      }
      await this.refreshData();
      this.renderTeamMembersList();
      this.render();
      this.showToast(`ลบสมาชิก "${member.name}" เรียบร้อย`);
    }
  },

  // Delete Task with confirmation
  async confirmDeleteTask(taskId) {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return;

    if (confirm(`คุณต้องการลบงาน "${task.title}" ใช่หรือไม่?`)) {
      await Storage.deleteTask(taskId);
      await this.refreshData();
      this.render();
      this.showToast('ลบงานเรียบร้อยแล้ว');
    }
  },

  // Backup Import Modal
  openImportModal() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async (evt) => {
        try {
          const success = await Storage.importBackup(evt.target.result);
          if (success) {
            await this.refreshData();
            this.render();
            this.showToast('นำเข้าข้อมูลสำเร็จแล้ว!');
          } else {
            alert('รูปแบบไฟล์ JSON ไม่ถูกต้อง');
          }
        } catch (err) {
          alert('เกิดข้อผิดพลาดในการอ่านไฟล์');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  },

  // Toast Notifications
  showToast(message, type = 'success') {
    const toast = document.getElementById('toast-notification');
    const toastMsg = document.getElementById('toast-message');
    if (!toast || !toastMsg) return;

    toastMsg.textContent = message;
    toast.className = `fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl text-white text-xs font-semibold transition-all transform duration-300 ${
      type === 'error' ? 'bg-red-600' : 'bg-slate-900 dark:bg-blue-600'
    }`;

    toast.classList.remove('translate-y-20', 'opacity-0');
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => {
      toast.classList.add('translate-y-20', 'opacity-0');
    }, 3000);
  }
};

window.App = App;

// Auto initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
  document.addEventListener('click', (e) => App.closeProfileDropdownOnOutside(e));
});
