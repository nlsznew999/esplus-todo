// Initial Seed Data for Esplustodo

window.DEFAULT_MEMBERS = [
  { id: 'm-1', name: 'สมชาย วงศ์สวัสดิ์', role: 'Lead Developer', avatar: '👨‍💻', color: '#3b82f6', email: 'somchai@company.com' },
  { id: 'm-2', name: 'กัญญา รัตนพงษ์', role: 'UI/UX Designer', avatar: '🎨', color: '#ec4899', email: 'kanya@company.com' },
  { id: 'm-3', name: 'อานนท์ ฤทธิรงค์', role: 'Frontend Developer', avatar: '⚡', color: '#10b981', email: 'anon@company.com' },
  { id: 'm-4', name: 'สุภาพร นามดี', role: 'QA & Project Manager', avatar: '📋', color: '#f59e0b', email: 'supaporn@company.com' }
];

window.DEFAULT_TASKS = [
  {
    id: 't-1',
    title: 'ออกแบบ Wireframe หน้า Dashboard ใหม่',
    description: 'ออกแบบ layout หน้าภาพรวมทีมให้ดูง่าย รองรับทั้ง desktop และ mobile แสดงสถิติและสถานะงานชัดเจน',
    assignee_id: 'm-2',
    status: 'done',
    priority: 'high',
    start_date: '2026-11-01',
    due_date: '2026-11-05',
    tags: ['Design', 'UI/UX'],
    created_at: '2026-11-01T09:00:00Z',
    updated_at: '2026-11-05T16:00:00Z'
  },
  {
    id: 't-2',
    title: 'เชื่อมต่อ Cloudflare D1 Database',
    description: 'ตั้งค่า schema และทดสอบเขียน-อ่านข้อมูลผ่าน Cloudflare Pages Functions ให้ข้อมูลซิงค์ตรงกัน',
    assignee_id: 'm-1',
    status: 'in_progress',
    priority: 'urgent',
    start_date: '2026-11-04',
    due_date: '2026-11-08',
    tags: ['Backend', 'Cloudflare'],
    created_at: '2026-11-04T10:00:00Z',
    updated_at: '2026-11-06T14:30:00Z'
  },
  {
    id: 't-3',
    title: 'พัฒนา Component สำหรับ Kanban Board',
    description: 'ทำฟังก์ชัน Drag & Drop สำหรับย้ายการ์ดงานระหว่าง 4 คอลัมน์ (To Do, In Progress, In Review, Done)',
    assignee_id: 'm-3',
    status: 'in_progress',
    priority: 'high',
    start_date: '2026-11-05',
    due_date: '2026-11-09',
    tags: ['Frontend', 'Kanban'],
    created_at: '2026-11-05T11:00:00Z',
    updated_at: '2026-11-06T15:00:00Z'
  },
  {
    id: 't-4',
    title: 'ทดสอบระบบเปลี่ยนสถานะและ Deadline Alert',
    description: 'เขียน Test cases ตรวจสอบการแจ้งเตือนงานที่ใกล้ถึงกำหนดส่ง (สีส้ม) และเลยกำหนด (สีแดง)',
    assignee_id: 'm-4',
    status: 'todo',
    priority: 'medium',
    start_date: '2026-11-07',
    due_date: '2026-11-12',
    tags: ['QA', 'Testing'],
    created_at: '2026-11-07T08:30:00Z',
    updated_at: '2026-11-07T08:30:00Z'
  },
  {
    id: 't-5',
    title: 'ปรับแต่ง UI Color Scheme ให้รองรับ Dark Mode',
    description: 'ทำ theme สีให้สบายตาและสามารถสลับโหมดได้ เข้ากับโทนแอปสมัยใหม่',
    assignee_id: 'm-2',
    status: 'in_review',
    priority: 'low',
    start_date: '2026-11-02',
    due_date: '2026-11-07',
    tags: ['Design', 'CSS'],
    created_at: '2026-11-02T13:00:00Z',
    updated_at: '2026-11-06T18:00:00Z'
  },
  {
    id: 't-6',
    title: 'จัดทำเอกสารคู่มือการใช้งานระบบทีม',
    description: 'เขียนสรุปวิธีการสร้างงาน ย้ายสถานะ และการสลับหน้าสมาชิกสำหรับทีมงาน',
    assignee_id: 'm-4',
    status: 'todo',
    priority: 'low',
    start_date: '2026-11-08',
    due_date: '2026-11-15',
    tags: ['Docs'],
    created_at: '2026-11-07T09:15:00Z',
    updated_at: '2026-11-07T09:15:00Z'
  }
];
