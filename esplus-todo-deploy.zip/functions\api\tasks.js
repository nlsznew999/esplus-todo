// Cloudflare Pages Function: /api/tasks

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

export async function onRequestOptions() {
  return jsonResponse({ ok: true });
}

// GET /api/tasks
export async function onRequestGet(context) {
  const { env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const { results } = await env.DB.prepare(
      "SELECT * FROM tasks ORDER BY created_at DESC"
    ).all();

    // Parse tags if JSON string
    const formatted = (results || []).map(t => {
      let tags = [];
      try {
        tags = typeof t.tags === 'string' ? JSON.parse(t.tags) : (t.tags || []);
      } catch (e) {
        tags = t.tags ? [t.tags] : [];
      }
      return { ...t, tags };
    });

    return jsonResponse(formatted);
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// POST /api/tasks
export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const body = await request.json();
    const id = body.id || 't-' + Date.now();
    const {
      title,
      description = '',
      assignee_id = null,
      status = 'todo',
      priority = 'medium',
      start_date = new Date().toISOString().split('T')[0],
      due_date = null,
      tags = []
    } = body;

    if (!title) {
      return jsonResponse({ error: "Title is required" }, 400);
    }

    const tagsJson = JSON.stringify(tags || []);
    const now = new Date().toISOString();

    await env.DB.prepare(
      `INSERT INTO tasks (id, title, description, assignee_id, status, priority, start_date, due_date, tags, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(id, title, description, assignee_id, status, priority, start_date, due_date, tagsJson, now, now).run();

    return jsonResponse({
      success: true,
      task: { id, title, description, assignee_id, status, priority, start_date, due_date, tags, created_at: now, updated_at: now }
    });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// PUT /api/tasks
export async function onRequestPut(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const body = await request.json();
    const {
      id,
      title,
      description,
      assignee_id,
      status,
      priority,
      start_date,
      due_date,
      tags
    } = body;

    if (!id) {
      return jsonResponse({ error: "Task ID is required" }, 400);
    }

    const now = new Date().toISOString();
    const tagsJson = tags ? JSON.stringify(tags) : '[]';

    await env.DB.prepare(
      `UPDATE tasks
       SET title = COALESCE(?, title),
           description = COALESCE(?, description),
           assignee_id = ?,
           status = COALESCE(?, status),
           priority = COALESCE(?, priority),
           start_date = COALESCE(?, start_date),
           due_date = ?,
           tags = COALESCE(?, tags),
           updated_at = ?
       WHERE id = ?`
    ).bind(
      title !== undefined ? title : null,
      description !== undefined ? description : null,
      assignee_id,
      status !== undefined ? status : null,
      priority !== undefined ? priority : null,
      start_date !== undefined ? start_date : null,
      due_date !== undefined ? due_date : null,
      tagsJson,
      now,
      id
    ).run();

    return jsonResponse({ success: true, updatedId: id });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// DELETE /api/tasks?id=xxx
export async function onRequestDelete(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    if (!id) {
      return jsonResponse({ error: "Missing task id" }, 400);
    }

    await env.DB.prepare("DELETE FROM tasks WHERE id = ?").bind(id).run();
    return jsonResponse({ success: true, deletedId: id });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}
