// Cloudflare Pages Function: /api/members

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

export async function onRequestOptions() {
  return jsonResponse({ ok: true });
}

// GET /api/members
export async function onRequestGet(context) {
  const { env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const { results } = await env.DB.prepare(
      "SELECT * FROM members ORDER BY name ASC"
    ).all();
    return jsonResponse(results || []);
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// POST /api/members
export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const body = await request.json();
    const id = body.id || 'm-' + Date.now();
    const { name, role, avatar = '👤', color = '#3b82f6', email = '' } = body;

    if (!name || !role) {
      return jsonResponse({ error: "Name and role are required" }, 400);
    }

    await env.DB.prepare(
      "INSERT INTO members (id, name, role, avatar, color, email) VALUES (?, ?, ?, ?, ?, ?)"
    ).bind(id, name, role, avatar, color, email).run();

    return jsonResponse({ success: true, id, name, role, avatar, color, email });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// PUT /api/members
export async function onRequestPut(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const body = await request.json();
    const { id, name, role, avatar, color, email } = body;

    if (!id || !name || !role) {
      return jsonResponse({ error: "ID, name, and role are required" }, 400);
    }

    await env.DB.prepare(
      "UPDATE members SET name = ?, role = ?, avatar = ?, color = ?, email = ? WHERE id = ?"
    ).bind(name, role, avatar, color, email, id).run();

    return jsonResponse({ success: true, member: body });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}

// DELETE /api/members?id=xxx
export async function onRequestDelete(context) {
  const { request, env } = context;
  if (!env.DB) {
    return jsonResponse({ error: "Cloudflare D1 binding (DB) is not configured" }, 500);
  }

  try {
    const url = new URL(request.url);
    const id = url.searchParams.get("id");
    if (!id) {
      return jsonResponse({ error: "Missing member id" }, 400);
    }

    // Set tasks assignee to null or handle
    await env.DB.prepare("UPDATE tasks SET assignee_id = NULL WHERE assignee_id = ?").bind(id).run();
    await env.DB.prepare("DELETE FROM members WHERE id = ?").bind(id).run();

    return jsonResponse({ success: true, deletedId: id });
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
}
