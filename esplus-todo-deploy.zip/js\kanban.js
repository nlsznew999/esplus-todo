// Kanban Board Component and Drag-and-Drop Handler

const Kanban = {
  columns: [
    { id: 'todo', title: 'รอดำเนินการ', subtitle: 'To Do', color: 'border-slate-300 dark:border-slate-700', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', dot: 'bg-slate-400' },
    { id: 'in_progress', title: 'กำลังดำเนินการ', subtitle: 'In Progress', color: 'border-blue-400 dark:border-blue-700', badge: 'bg-blue-50 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300', dot: 'bg-blue-500' },
    { id: 'in_review', title: 'รอตรวจสอบ', subtitle: 'In Review', color: 'border-amber-400 dark:border-amber-700', badge: 'bg-amber-50 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', dot: 'bg-amber-500' },
    { id: 'done', title: 'เสร็จสิ้นแล้ว', subtitle: 'Done', color: 'border-emerald-400 dark:border-emerald-700', badge: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300', dot: 'bg-emerald-500' }
  ],

  draggedTaskId: null,

  initDragAndDrop(containerSelector, onTaskDrop) {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    // Delegate drag events
    container.querySelectorAll('.kanban-column').forEach(column => {
      const colId = column.dataset.status;
      const dropZone = column.querySelector('.kanban-cards-container');

      dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        dropZone.classList.add('bg-blue-50/50', 'dark:bg-blue-950/20', 'border-dashed', 'border-2', 'border-blue-400');
      });

      dropZone.addEventListener('dragleave', (e) => {
        if (!dropZone.contains(e.relatedTarget)) {
          dropZone.classList.remove('bg-blue-50/50', 'dark:bg-blue-950/20', 'border-dashed', 'border-2', 'border-blue-400');
        }
      });

      dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-blue-50/50', 'dark:bg-blue-950/20', 'border-dashed', 'border-2', 'border-blue-400');
        const taskId = e.dataTransfer.getData('text/plain') || this.draggedTaskId;
        if (taskId && onTaskDrop) {
          onTaskDrop(taskId, colId);
        }
      });
    });
  },

  // Helper: Format Priority Badge
  getPriorityBadge(priority) {
    const map = {
      urgent: { label: 'ด่วนมาก', class: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/40 dark:text-red-300 dark:border-red-800' },
      high: { label: 'สูง', class: 'bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-900/40 dark:text-orange-300 dark:border-orange-800' },
      medium: { label: 'ปานกลาง', class: 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-800' },
      low: { label: 'ทั่วไป', class: 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700' }
    };
    const p = map[priority] || map.medium;
    return `<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${p.class}">${p.label}</span>`;
  },

  // Helper: Format Deadline Badge with intelligent alert
  getDeadlineBadge(dueDate, status) {
    if (!dueDate) return `<span class="text-xs text-slate-400 dark:text-slate-500">ไม่มีกำหนด</span>`;

    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const due = new Date(dueDate);
    due.setHours(0, 0, 0, 0);

    const diffDays = Math.round((due - now) / (1000 * 60 * 60 * 24));

    if (status === 'done') {
      return `
        <span class="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
          <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
          ${dueDate}
        </span>
      `;
    }

    if (diffDays < 0) {
      return `
        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 animate-pulse">
          <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          เลยกำหนด (${Math.abs(diffDays)} วัน)
        </span>
      `;
    } else if (diffDays === 0) {
      return `
        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300">
          <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          กำหนดส่งวันนี้!
        </span>
      `;
    } else if (diffDays <= 2) {
      return `
        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300">
          <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          เหลืออีก ${diffDays} วัน (${dueDate})
        </span>
      `;
    }

    return `
      <span class="inline-flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
        <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
        ${dueDate}
      </span>
    `;
  },

  // Render a Single Kanban Card
  renderCard(task, member, isMasterView = false) {
    const memberColor = member ? member.color : '#94a3b8';
    const memberName = member ? member.name : 'ยังไม่ระบุผู้รับผิดชอบ';
    const memberAvatar = member ? member.avatar : '👤';

    const tagsHtml = (task.tags || []).map(t => 
      `<span class="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">#${t}</span>`
    ).join('');

    return `
      <div 
        id="task-card-${task.id}"
        class="task-card group relative bg-white dark:bg-slate-800/90 rounded-xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-700/80 hover:shadow-md hover:border-blue-400 dark:hover:border-blue-500 transition-all duration-150 cursor-grab active:cursor-grabbing mb-3"
        draggable="true"
        data-task-id="${task.id}"
      >
        <!-- Top row: Priority & Actions -->
        <div class="flex items-center justify-between gap-2 mb-2">
          ${this.getPriorityBadge(task.priority)}
          
          <div class="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
            <button 
              onclick="App.openEditTaskModal('${task.id}')"
              title="แก้ไขงาน" 
              class="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
            </button>
            <button 
              onclick="App.confirmDeleteTask('${task.id}')"
              title="ลบงาน" 
              class="p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/30 text-slate-400 hover:text-red-600 dark:hover:text-red-400"
            >
              <svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </div>

        <!-- Task Title -->
        <h4 
          onclick="App.openTaskDetailModal('${task.id}')"
          class="font-semibold text-slate-900 dark:text-white text-sm line-clamp-2 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer mb-1.5"
        >
          ${task.title}
        </h4>

        <!-- Task Description Preview -->
        ${task.description ? `
          <p class="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-3 leading-relaxed">
            ${task.description}
          </p>
        ` : ''}

        <!-- Tags -->
        ${tagsHtml ? `<div class="flex flex-wrap gap-1 mb-3">${tagsHtml}</div>` : ''}

        <!-- Bottom row: Assignee & Deadline -->
        <div class="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between gap-2 mt-auto">
          <!-- Assignee badge -->
          <div 
            class="flex items-center gap-1.5 min-w-0" 
            title="${memberName}"
            ${isMasterView && member ? `onclick="App.switchView('member', '${member.id}')" role="button"` : ''}
          >
            <span class="w-6 h-6 rounded-full flex items-center justify-center text-xs text-white shadow-sm flex-shrink-0" style="background-color: ${memberColor}">
              ${memberAvatar}
            </span>
            <span class="text-xs text-slate-700 dark:text-slate-300 font-medium truncate max-w-[110px] ${isMasterView && member ? 'hover:underline cursor-pointer' : ''}">
              ${memberName.split(' ')[0]}
            </span>
          </div>

          <!-- Deadline -->
          <div>
            ${this.getDeadlineBadge(task.due_date, task.status)}
          </div>
        </div>
      </div>
    `;
  },

  // Render Full Kanban Board HTML
  renderBoard(tasks, members, currentMemberId = null, filterText = '', filterPriority = 'all') {
    const isMasterView = !currentMemberId;
    const memberMap = new Map(members.map(m => [m.id, m]));

    // Filter tasks
    let filteredTasks = tasks.filter(task => {
      // Member filter
      if (currentMemberId && task.assignee_id !== currentMemberId) {
        return false;
      }
      // Priority filter
      if (filterPriority !== 'all' && task.priority !== filterPriority) {
        return false;
      }
      // Search text filter
      if (filterText) {
        const query = filterText.toLowerCase();
        const titleMatch = task.title.toLowerCase().includes(query);
        const descMatch = (task.description || '').toLowerCase().includes(query);
        const tagsMatch = (task.tags || []).some(t => t.toLowerCase().includes(query));
        const assignee = memberMap.get(task.assignee_id);
        const nameMatch = assignee && assignee.name.toLowerCase().includes(query);
        if (!titleMatch && !descMatch && !tagsMatch && !nameMatch) return false;
      }
      return true;
    });

    // Generate 4 columns HTML
    const columnsHtml = this.columns.map(col => {
      const colTasks = filteredTasks.filter(t => t.status === col.id);
      const cardsHtml = colTasks.length > 0
        ? colTasks.map(t => this.renderCard(t, memberMap.get(t.assignee_id), isMasterView)).join('')
        : `
          <div class="h-32 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 text-xs gap-1 select-none">
            <svg class="w-6 h-6 stroke-current opacity-40" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            <span>ไม่มีงานในสถานะนี้</span>
          </div>
        `;

      return `
        <div class="kanban-column flex flex-col bg-slate-100/70 dark:bg-slate-900/60 rounded-2xl p-3 border ${col.color} min-w-[290px] w-full" data-status="${col.id}">
          <!-- Column Header -->
          <div class="flex items-center justify-between pb-3 px-1 border-b border-slate-200 dark:border-slate-800 mb-3">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full ${col.dot}"></span>
              <h3 class="font-bold text-slate-800 dark:text-slate-100 text-sm">
                ${col.title}
              </h3>
              <span class="px-2 py-0.5 rounded-full text-xs font-semibold ${col.badge}">
                ${colTasks.length}
              </span>
            </div>
            
            <button 
              onclick="App.openCreateTaskModal('${col.id}', '${currentMemberId || ''}')"
              class="p-1 rounded-lg hover:bg-white dark:hover:bg-slate-800 text-slate-500 hover:text-blue-600 transition-colors"
              title="เพิ่มงานในคอลัมน์นี้"
            >
              <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            </button>
          </div>

          <!-- Cards Scrollable Container -->
          <div class="kanban-cards-container flex-1 overflow-y-auto pr-1 min-h-[350px] transition-colors rounded-xl p-1">
            ${cardsHtml}
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
        ${columnsHtml}
      </div>
    `;
  },

  // Attach card drag listeners after HTML insertion
  bindCardDragEvents(containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    container.querySelectorAll('.task-card').forEach(card => {
      card.addEventListener('dragstart', (e) => {
        const taskId = card.dataset.taskId;
        this.draggedTaskId = taskId;
        e.dataTransfer.setData('text/plain', taskId);
        e.dataTransfer.effectAllowed = 'move';
        setTimeout(() => card.classList.add('opacity-40', 'scale-95'), 0);
      });

      card.addEventListener('dragend', () => {
        this.draggedTaskId = null;
        card.classList.remove('opacity-40', 'scale-95');
      });
    });
  }
};

window.Kanban = Kanban;
